package exercicios;

import java.util.Scanner;

import filas.FilaInt;

public class Exercicio1 {
	
	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		FilaInt fila = new FilaInt();
		fila.init();
		System.out.println("Digite um valor positivo para enfileirar, ou negativo para sair");
		int valor = le.nextInt();
		while (valor >= 0) {
			// Insere na fila o valor digitado
			valor = le.nextInt();
		}
		le.close();
		
		while (!fila.isEmpty()) {
			System.out.println("Valor retirado  da fila: " + fila.dequeue());
		}
		le.close();	
	}

}
