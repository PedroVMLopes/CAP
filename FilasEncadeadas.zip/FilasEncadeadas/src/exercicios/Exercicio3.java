package exercicios;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {

		Scanner le = new Scanner(System.in);
		
		// Cria fila de nomes
		FilaString = fila
		int op;
		do {
			System.out.println("1 - insere paciente na fila: ");
			System.out.println("2 - chama paciente para atendimento");
			System.out.println("3 - Encerra atendimento do dia:");
			System.out.print("Op��o: ");
			op = le.nextInt();
			
			switch (op) {
			case 1:
				System.out.println("Nome do paciente: ");
				String nome = le.next();
				// insere o nome da fila
				fila.enqueue();
				break;
			case 2:
				if(!fila.isempty())
					System.out.println("Paciente chamado para o atendimento: " + fila.dequeue());
				break;
			case 3:
				break;
			default:
				System.out.println(" Op��o Inv�lida");
			}
		}while(op != 3);
		
	}

}
